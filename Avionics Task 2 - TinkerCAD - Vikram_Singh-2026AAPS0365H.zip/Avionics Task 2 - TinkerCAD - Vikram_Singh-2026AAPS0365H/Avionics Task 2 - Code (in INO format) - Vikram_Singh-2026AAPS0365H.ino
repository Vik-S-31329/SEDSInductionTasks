#include <Adafruit_LiquidCrystal.h>                                // Include libraries to be used - Adadfruit LC for I2C communications
int dist = 0;                                                      // Declare variables to be used over the program - first stores distance... the program
int light = 0;                                                     // ...the next stores light level...
int status = 0;                                                    // ...the next stores status code of sensors...
int pushbutton = 0;                                                // ...the next stores the push button's state...
static unsigned long int time = 0UL;                               // ...and the last stores the trigger time for each sensor

Adafruit_LiquidCrystal lcd_1(0);                                   // This line of code declares the LCD object to the Arduino/library

long readUltrasonicDistance(int triggerPin, int echoPin)           // Function to get distince of object from ultrasonic sensor
{
  pinMode(triggerPin, OUTPUT);                                     // Set the trigger pin for the measuring pulse, followed by reseting it to the low (no-pulse) position
  digitalWrite(triggerPin, LOW);
  delayMicroseconds(2);
  // Sets the trigger pin to HIGH state for 10 microseconds
  digitalWrite(triggerPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(triggerPin, LOW);
  pinMode(echoPin, INPUT);
  // Reads the echo pin, and returns the sound wave travel time in microseconds
  return pulseIn(echoPin, HIGH);
}

void setup()
{
  lcd_1.begin(16, 2);                                               // Initialize the LCD, providing its dimensions
  pinMode(A0, INPUT);                                               // Set the various pin to their taks - first to recieve light sensor's value...
  pinMode(7, INPUT_PULLUP);                                         // ...the next to fetch the button state...
  pinMode(3, OUTPUT);                                               // ...the next to control the LED...
  pinMode(2, OUTPUT);                                               // ...and the last to control the buzzer..

  lcd_1.print("Hello");                                             // Display the LCD's startup message (cheap-ass splash screen,but it works)
  delay(100);                                                       // Wait for 100 millisecond(s) - allows time to read the text
  lcd_1.clear();                                                    // Clear the LCD screen - prepares it for input
}

void loop()
{
  dist = 0.01723 * readUltrasonicDistance(5, 6);                    // Convert the value received from the sensor to in cm
  light = analogRead(A0);                                           // Read the light sensor's value, and stores the value
  int Butn = digitalRead(7);                                        //Log pressed for the button - only works for holding after pressing, was unable to perfect the system, unfortunately
  if (Butn == LOW) {
    pushbutton += 1;
    delay(1);

  }
  if (pushbutton % 2 == 1) {
    status = 1;                                                    //Set status to the code for "Button pressed",...
  } else if (light <= 612) {
    status = 2;                                                    //...for "Low light level" (value of threshold derived manually)...
    if (time == 0) {
  		time = millis();                                           //...while logging timestamp for 5-second countdown...
  	}
  }	else if (dist <= 100) {
    status = 3;                                                    //...and similarly for "Low distance" (value of threshold derived manually)..
    if (time == 0) {
  		time = millis();
  	}
  } else if (dist >= 100 || light >= 612) {
  	status = 0;                                                    //...and lastly, for the "All clear" condition
  }
  lcd_1.clear();                                                   // Clear LCD of any residual output, preparing for the next message
  long unsigned int time_curr = millis();                          // Record time of the current iteration fo the sensor-processing loop - used for time difference for 5-second countdown
  if (status == 0) {
  	lcd_1.print("CLEAR SEA");                                      // Reflect the "All clear" status on the LCD, while ensuring no other errors are trigerred
    time = 0;
  } else if  (pushbutton % 2 == 1) {
  	lcd_1.print("ANCHOR DROPPED");                                 // Reflect the "Anchor dropped" status on the LCD, which neccesotitates no other errors occur
    time = 0;
  } else if (status == 2 && time_curr - time < 4990) {
    lcd_1.print("LOW LIGHT");                                      // Reflect the "Low light" status on the LCD, and blink the LED correspondingly
    digitalWrite(2, HIGH);
 	delayMicroseconds(500);
  	digitalWrite(2, LOW);
  }	else if (status == 3 && time_curr - time < 4990) {
  	lcd_1.print("CHARYBDIS");
    digitalWrite(3, HIGH);                                          // Reflect the "Charybdis" status on the LCD, and buzz the buzzer correspondingly
 	delayMicroseconds(500);
  	digitalWrite(3, LOW);
  }	else if (time_curr - time >= 4990) {
  	lcd_1.print("WRECKED");                                         // Reflect the "Wrecked" status on the LCD, and exit the program , preventing further action - used 4990 milliseconds as I am accounting for computational time
	exit;
  }

  delay(5);                                                         // Delay a little bit to improve simulation performance - Reduced to get more accurate results
}
