import csv

import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

arr = []
inv = []
with open("data.csv", mode="r", newline="", encoding="utf-8") as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        arr.append(row)
del arr[0]  # remove header row

filtered = []
for row in arr:
    try:
        value = float(row[1])
    except ValueError:
        inv.append(row[0])
        continue  # not a valid number — drop it
    if -600 < value < 0:
        filtered.append([float(row[0]), value])
    else:
        inv.append(row[0])

# CubicSpline needs x strictly increasing — sort and drop any
# duplicate timestamps before building it.
filtered.sort(key=lambda r: r[0])
deduped, seen = [], set()
for t, v in filtered:
    if t not in seen:
        deduped.append([t, v])
        seen.add(t)
filtered = deduped

temp = [list(col) for col in zip(*filtered)]
pred = CubicSpline(temp[0], temp[1], bc_type="natural")

# Rebuild the full series (real + interpolated), then sort chronologically
full = list(filtered)
for item in inv:
    t = float(item)
    full.append([t, float(pred(t))])
full.sort(key=lambda r: r[0])

x, y = [], []
plt.ion()
for t, v in full:
    x.append(t)
    y.append(v)
    plt.plot(x, y, "p:c")
    plt.xlabel("Time (s)")
    plt.ylabel("Depth (m)")
    plt.show()
    plt.pause(0.1)
    plt.clf()
