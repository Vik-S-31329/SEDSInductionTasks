# Here, I had written my code originally by myself, except for a part which I handed over to AI (Sonnet 5 at High effort, to be precise).
# Later on, I aske it to clean it up, I asked it to clean up the code for me, for beautification.
# Also, I opted out of PyQT5, as I was already using matplotlib for plotting, which uses the same Qt toolkoit , but can workm on alternatives
# UI toolkits, allowing for maximum efficieny with my code - also, I was more comoforatble with it.

import csv                                                                                           # Importing the libraries neccesary - csv to read the file,
import matplotlib.pyplot as plt                                                                      # MatPlotLib to draw the graph,
from scipy.interpolate import CubicSpline                                                            # and SciPy's CubicSpline to interpolate the data for error correction.

arr = []                                                                                             # Creating arrays to store data - opted for them as they are native to Python.
inv = []                                                                                             # minimizing dependence on libraraies and levaraging the language's native data manipulation capabilities.
with open("data.csv", mode="r", newline="", encoding="utf-8") as file:                          # Main code to read CSV into 2D array - asked AI, as it was my first time working with CSVs.
    csv_reader = csv.reader(file)
    for row in csv_reader:
        arr.append(row)                                                                              # Removed the header row, leaving only numeric data values.
del arr[0]

filtered = []                                                                                        # Created a array to store the correct values from the table for interpolation by SciPy
for row in arr:                                                                                      # Code for filtering the values - wrote on my own, was changed in the cleanup.
    try:                                                                                             # Code first stores depth value from array in a float, then accpets if it passes the given constraints.
        value = float(row[1])
    except ValueError:
        inv.append(row[0])                                                                           # Append value to array of values to be processed in case of no value errors...
        continue
    if -600 < value < 0:
        filtered.append([float(row[0]), value])                                                      # Append value to array of accepted values only if it passes the constraints (derived by analysing graph manually - .
    else:                                                                                            # wanted to base it off differences between consecutive values, but was unable to do so).
        inv.append(row[0])                                                                           # Append value to array of values to be processed in case it lies outside the constraints (outlier elimination)
# CubicSpline needs x strictly increasing — sort and drop any
# duplicate timestamps before building it.
filtered.sort(key=lambda r: r[0])                                                                    # Following code sorts the array, storing the results in a array temporarily before replacing the original's
deduped, seen = [], set()                                                                            # contents with that of the new one - above 2 single-line comments by AI.
for t, v in filtered:
    if t not in seen:
        deduped.append([t, v])
        seen.add(t)
filtered = deduped

temp = [list(col) for col in zip(*filtered)]                                                         # Invert the rows and columns of the filtered array for further processing
pred = CubicSpline(temp[0], temp[1], bc_type="natural")                                          # The actual noise clearance - Using CubicSpline, construct a function to fill in the invalid data points fromm the valid ones

# Rebuild the full series (real + interpolated), then sort chronologically
full = list(filtered)                                                                                # Again, an AI comment - and it actually helps in explaining the code
for item in inv:
    t = float(item)
    full.append([t, float(pred(t))])
full.sort(key=lambda r: r[0])

x, y = [], []                                                                                        #The final array for MatPlotLib to use - for the x- and y-axis, respectively
plt.ion()                                                                                            # Activate Interactive Modefor the graphing area- allpws for redraws with new data.
for t, v in full:
    x.append(t)                                                                                      # Add new data point to the array for the x-axis
    y.append(v)                                                                                      # Add new data point to the array for the y-axis
    plt.plot(x, y, "p:c")                                                                            # Plot the data points, with formatting - went for pentagonal cyan datapoints with a dooted line conenecting them
    plt.xlabel("Time (s)")                                                                    # Added appropriate labels to the x- and y-axis
    plt.ylabel("Depth (m)")
    plt.show()                                                                                       # Showed the updated plot
    plt.pause(0.99)                                                                                  # Hold the graph on the screen for 990 ms - am assuming 10ms for processing the above instrustions
    plt.clf()                                                                                        # Claer the screen for the graph with the next value - iterarate this for all values till the end (closes the window at that point)
